#!/usr/bin/env python3
"""
GitHub仓库自动更新脚本
- 从源站抓取帖子数据
- 生成SEO友好的README.md
- 按分类组织软件列表
- 生成每个软件的详情页
"""

import requests
import re
import json
import time
import os
import urllib3
from datetime import datetime

urllib3.disable_warnings()

SOURCE_SITE = "http://img.lysq.cc.cd"
DATA_FILE = "data.json"
REPO_DIR = os.path.dirname(os.path.abspath(__file__))

def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")

def fetch_post_list():
    """获取帖子ID列表"""
    resp = requests.get(SOURCE_SITE, verify=False, timeout=15, headers={"User-Agent": "Mozilla/5.0"})
    ids = re.findall(r'software\.php\?id=(\d+)', resp.text)
    return list(dict.fromkeys(ids))

def fetch_post_detail(post_id):
    """抓取帖子详情"""
    url = f"{SOURCE_SITE}/software.php?id={post_id}"
    try:
        resp = requests.get(url, verify=False, timeout=15, headers={"User-Agent": "Mozilla/5.0"})
        html = resp.text
        
        title_match = re.search(r'<title>(.*?)</title>', html)
        title = title_match.group(1) if title_match else ""
        title = re.sub(r'林夕软件库\s*-\s*', '', title).strip()
        
        # 正文
        desc_match = re.search(r'<p class="detail-description-text"[^>]*>(.*?)</p>', html, re.DOTALL)
        content = ""
        if desc_match:
            content = re.sub(r'<br\s*/?>', '\n', desc_match.group(1))
            content = re.sub(r'<[^>]+>', '', content)
            content = content.replace('&amp;', '&').replace('&nbsp;', ' ').strip()
        
        # 截图
        screenshots = []
        for match in re.finditer(r'src="(uploads/screenshots/[^"]+)"', html):
            img_url = f"{SOURCE_SITE}/{match.group(1)}"
            if img_url not in screenshots:
                screenshots.append(img_url)
        
        # 网盘链接
        download_link = ""
        dl_btn = re.search(r'href="(download\.php\?id=\d+[^"]*)"', html)
        if dl_btn:
            dl_url = f"{SOURCE_SITE}/{dl_btn.group(1)}"
            try:
                dl_resp = requests.get(dl_url, verify=False, timeout=15, 
                                       headers={"User-Agent": "Mozilla/5.0"}, allow_redirects=True)
                for pattern in [r'https?://pan\.baidu\.com/s/[^\s"<>]+', r'https?://pan\.quark\.cn/s/[^\s"<>]+']:
                    match = re.search(pattern, dl_resp.text)
                    if match:
                        download_link = match.group(0)
                        break
            except:
                pass
        
        # 分类
        cat_match = re.search(r'category\.php\?id=(\d+)">([^<]+)</a>', html)
        category = cat_match.group(2).strip() if cat_match else "未分类"
        
        return {
            "id": post_id,
            "title": title,
            "content": content,
            "screenshots": screenshots,
            "download_link": download_link,
            "category": category,
            "source_url": url,
            "updated_at": datetime.now().isoformat(),
        }
    except Exception as e:
        log(f"抓取失败 ID={post_id}: {e}")
        return None

def generate_readme(posts):
    """生成主README.md"""
    content = """# 林夕软件库 - 精选软件资源分享

> 每日更新优质软件、游戏、工具资源。所有资源均经过测试，提供网盘高速下载。

## 关于

林夕软件库致力于分享**精品软件、实用工具、破解应用**，涵盖：

- Android 应用（破解版、去广告、解锁会员）
- PC 软件（绿色版、便携版、专业版）
- 在线工具（视频下载、格式转换、AI工具）
- 游戏（单机、模拟器、修改版）

**网站地址**: [http://img.lysq.cc.cd](http://img.lysq.cc.cd)

**更新频率**: 每日更新

---

## 目录

- [最新软件列表](#最新软件列表)
- [分类索引](#分类索引)
- [使用指南](#使用指南)
- [免责声明](#免责声明)

---

## 最新软件列表

| 编号 | 软件名称 | 分类 | 下载 |
|------|----------|------|------|
"""
    
    for post in posts[:50]:  # 只显示最新50条
        title = post.get("title", "")
        category = post.get("category", "未分类")
        post_id = post.get("id", "")
        download = "[下载]({})".format(post.get("download_link", "#")) if post.get("download_link") else "-"
        
        # 截断过长的标题
        display_title = title[:40] + "..." if len(title) > 40 else title
        
        content += f"| {post_id} | {display_title} | {category} | {download} |\n"
    
    content += f"\n> 共收录 **{len(posts)}** 款软件，[查看更多](softwares/)\n\n"
    
    # 分类统计
    content += "## 分类索引\n\n"
    categories = {}
    for post in posts:
        cat = post.get("category", "未分类")
        categories.setdefault(cat, []).append(post)
    
    for cat_name, cat_posts in sorted(categories.items(), key=lambda x: -len(x[1])):
        content += f"- **{cat_name}** ({len(cat_posts)} 款)\n"
    
    content += """
---

## 使用指南

1. 在上方列表中找到需要的软件
2. 点击"下载"链接获取网盘地址
3. 根据网盘提示输入提取码（如有）
4. 下载安装即可使用

---

## 免责声明

本仓库仅作**软件资源索引**，所有软件版权归原作者或开发商所有。
- 破解软件仅供学习研究，请于24小时内删除
- 商业用途请购买正版
- 如有侵权请联系删除

**本站不对软件安全性做任何担保，请自行判断风险。**

---

*最后更新: {}*

*林夕软件库 公益分享*
""".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    
    return content

def generate_software_page(post):
    """生成单个软件的详情页"""
    post_id = post.get("id", "")
    title = post.get("title", "")
    content = post.get("content", "")
    screenshots = post.get("screenshots", [])
    download_link = post.get("download_link", "")
    category = post.get("category", "未分类")
    source_url = post.get("source_url", "")
    
    md = f"""# {title}

**分类**: {category} | **编号**: #{post_id}

---

## 软件简介

{content}

---

## 下载

"""
    if download_link:
        md += f"- **网盘下载**: [{download_link}]({download_link})\n"
    else:
        md += "- 下载链接获取中...\n"
    
    md += f"- **源站页面**: [{source_url}]({source_url})\n"
    
    if screenshots:
        md += "\n## 截图\n\n"
        for img in screenshots[:5]:
            md += f"![截图]({img})\n\n"
    
    md += "\n---\n\n"
    md += f"*更新于: {post.get('updated_at', datetime.now().isoformat())}*\n\n"
    md += "[返回主页](../README.md)\n"
    
    return md

def main():
    log("开始生成GitHub仓库内容...")
    
    # 创建目录
    softwares_dir = os.path.join(REPO_DIR, "softwares")
    os.makedirs(softwares_dir, exist_ok=True)
    
    # 获取帖子列表
    post_ids = fetch_post_list()
    log(f"获取到 {len(post_ids)} 个帖子")
    
    # 加载已有数据
    existing_data = {}
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                existing_data = {str(p["id"]): p for p in json.load(f)}
            log(f"加载已有数据: {len(existing_data)} 条")
        except:
            pass
    
    # 抓取详情（限制数量，避免太慢）
    posts = []
    max_posts = 100  # 先处理100条
    
    for i, pid in enumerate(post_ids[:max_posts]):
        pid_str = str(pid)
        
        # 如果有缓存且不太旧，直接用缓存
        if pid_str in existing_data and existing_data[pid_str].get("download_link"):
            posts.append(existing_data[pid_str])
            log(f"[{i+1}/{max_posts}] 使用缓存: {existing_data[pid_str]['title'][:30]}")
            continue
        
        # 否则抓取
        detail = fetch_post_detail(pid)
        if detail:
            posts.append(detail)
            existing_data[pid_str] = detail
            log(f"[{i+1}/{max_posts}] 抓取成功: {detail['title'][:30]}")
        time.sleep(0.5)
    
    # 保存数据
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(list(existing_data.values()), f, ensure_ascii=False, indent=2)
    log(f"数据已保存: {len(existing_data)} 条")
    
    # 生成README
    readme = generate_readme(posts)
    with open(os.path.join(REPO_DIR, "README.md"), 'w', encoding='utf-8') as f:
        f.write(readme)
    log("README.md 已生成")
    
    # 生成软件详情页
    for post in posts[:50]:  # 只生成前50个的详情页
        safe_name = re.sub(r'[^\w\-\s]', '', post.get("title", "")).strip()
        safe_name = safe_name.replace(" ", "-").replace("  ", "-")[:50]
        filename = f"{post['id']}-{safe_name}.md"
        filepath = os.path.join(softwares_dir, filename)
        
        page_content = generate_software_page(post)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(page_content)
    
    log(f"软件详情页已生成: {min(50, len(posts))} 个")
    log("完成!")

if __name__ == "__main__":
    main()
